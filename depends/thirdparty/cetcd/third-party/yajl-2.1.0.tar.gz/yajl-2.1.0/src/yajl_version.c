#include <yajl/yajl_version.h>

int yajl_version(void)
{
	return YAJL_VERSION;
}

